
public class AdaLovelace {

    public static void main(String[] args) {
        // Write your program here
        System.out.println("Ada Lovelace");
    }
}
