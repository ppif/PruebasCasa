
public class FromParameterToOne {

    public static void printFromNumberToOne(int number) {
        while (true) {
            if (number == 0) {
                break;
            }
            System.out.println(number);
            number--;
        }
    }

    public static void main(String[] args) {

    }

}
