# MOOC Java Programming 2020
 
Mooc = Massive Open Online Course 

University of Helsinki’s massive open online course (MOOC) on object-oriented programming!

MOOC 2020 OOProgramming with JAVA

https://java-programming.mooc.fi

El código que realizó (la resolución de los ejercicios) esta en la carpeta src (source)
 