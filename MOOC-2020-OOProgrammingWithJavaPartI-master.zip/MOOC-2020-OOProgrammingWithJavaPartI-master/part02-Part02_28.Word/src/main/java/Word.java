
import java.util.Scanner;

public class Word {

    public static String word() {
        return "easy";
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

    }

}
